package main;

public class Principal {

    public static void main(String[] args) {

        TelaProdutos tela = new TelaProdutos();
        tela.setVisible(true);
    }
}