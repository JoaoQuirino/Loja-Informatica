package main;

import dao.ProdutoDAO;
import model.Produto;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class TelaProdutos extends JFrame {

    private JTextField txtId;
    private JTextField txtNome;
    private JTextField txtMarca;
    private JTextField txtValor;
    private JTextField txtQuantidade;

    private JTable tabela;
    private DefaultTableModel modeloTabela;

    private ProdutoDAO dao = new ProdutoDAO();

    public TelaProdutos(String nomeUsuario) {

        setTitle("CRUD - Loja de Informática");
        setSize(850, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(null);

        getContentPane().setBackground(new Color(245, 245, 245));

        JLabel lblUsuario = new JLabel("Olá, " + nomeUsuario);
        lblUsuario.setBounds(40, 20, 200, 30);
        add(lblUsuario);

        JButton btnSair = new JButton("Sair");
        btnSair.setBounds(700, 20, 100, 30);
        add(btnSair);

        btnSair.addActionListener(e -> {
            TelaLogin telaLogin = new TelaLogin();
            telaLogin.setVisible(true);
            dispose();
        });
        
        JLabel titulo = new JLabel("Sistema de Produtos");
        titulo.setFont(new Font("Arial", Font.BOLD, 24));
        titulo.setBounds(280, 20, 300, 40);
        add(titulo);

        // ID
        JLabel lblId = new JLabel("ID:");
        lblId.setBounds(40, 90, 100, 30);
        add(lblId);

        txtId = new JTextField();
        txtId.setBounds(140, 90, 200, 30);
        add(txtId);

        // NOME
        JLabel lblNome = new JLabel("Nome:");
        lblNome.setBounds(40, 140, 100, 30);
        add(lblNome);

        txtNome = new JTextField();
        txtNome.setBounds(140, 140, 200, 30);
        add(txtNome);

        // MARCA
        JLabel lblMarca = new JLabel("Marca:");
        lblMarca.setBounds(40, 190, 100, 30);
        add(lblMarca);

        txtMarca = new JTextField();
        txtMarca.setBounds(140, 190, 200, 30);
        add(txtMarca);

        // VALOR
        JLabel lblValor = new JLabel("Valor:");
        lblValor.setBounds(40, 240, 100, 30);
        add(lblValor);

        txtValor = new JTextField();
        txtValor.setBounds(140, 240, 200, 30);
        add(txtValor);

        // QUANTIDADE
        JLabel lblQuantidade = new JLabel("Quantidade:");
        lblQuantidade.setBounds(40, 290, 100, 30);
        add(lblQuantidade);

        txtQuantidade = new JTextField();
        txtQuantidade.setBounds(140, 290, 200, 30);
        add(txtQuantidade);

        // BOTÕES
        JButton btnCadastrar = new JButton("Cadastrar");
        btnCadastrar.setBounds(420, 90, 150, 40);
        add(btnCadastrar);

        JButton btnListar = new JButton("Listar");
        btnListar.setBounds(600, 90, 150, 40);
        add(btnListar);

        JButton btnBuscar = new JButton("Buscar ID");
        btnBuscar.setBounds(420, 150, 150, 40);
        add(btnBuscar);

        JButton btnAtualizar = new JButton("Atualizar");
        btnAtualizar.setBounds(600, 150, 150, 40);
        add(btnAtualizar);

        JButton btnExcluir = new JButton("Excluir");
        btnExcluir.setBounds(420, 210, 150, 40);
        add(btnExcluir);

        JButton btnLimpar = new JButton("Limpar");
        btnLimpar.setBounds(600, 210, 150, 40);
        add(btnLimpar);

        // TABELA
        modeloTabela = new DefaultTableModel();

        modeloTabela.addColumn("ID");
        modeloTabela.addColumn("Nome");
        modeloTabela.addColumn("Marca");
        modeloTabela.addColumn("Valor");
        modeloTabela.addColumn("Quantidade");

        tabela = new JTable(modeloTabela);

        JScrollPane scrollPane = new JScrollPane(tabela);
        scrollPane.setBounds(40, 360, 760, 150);
        add(scrollPane);

        // CADASTRAR
        btnCadastrar.addActionListener(e -> {

            try {

                String nome = txtNome.getText();
                String marca = txtMarca.getText();

                double valor = Double.parseDouble(
                        txtValor.getText().replace(",", ".")
                );

                int quantidade = Integer.parseInt(
                        txtQuantidade.getText()
                );

                Produto produto = new Produto(
                        nome,
                        marca,
                        valor,
                        quantidade
                );

                dao.cadastrarProduto(produto);

                JOptionPane.showMessageDialog(
                        null,
                        "Produto cadastrado com sucesso!"
                );

                limparCampos();
                listarProdutos();

            } catch (Exception erro) {

                JOptionPane.showMessageDialog(
                        null,
                        "Erro ao cadastrar produto!"
                );
            }
        });

        // LISTAR
        btnListar.addActionListener(e -> {
            listarProdutos();
        });

        // BUSCAR
        btnBuscar.addActionListener(e -> {

            try {

                int id = Integer.parseInt(txtId.getText());

                Produto produto = dao.buscarPorId(id);

                if (produto != null) {

                    txtNome.setText(produto.getNome());
                    txtMarca.setText(produto.getMarca());
                    txtValor.setText(String.valueOf(produto.getPreco()));
                    txtQuantidade.setText(
                            String.valueOf(produto.getQuantidade())
                    );

                } else {

                    JOptionPane.showMessageDialog(
                            null,
                            "Produto não encontrado!"
                    );
                }

            } catch (Exception erro) {

                JOptionPane.showMessageDialog(
                        null,
                        "Informe um ID válido!"
                );
            }
        });

        // ATUALIZAR
        btnAtualizar.addActionListener(e -> {

            try {

                int id = Integer.parseInt(txtId.getText());

                String nome = txtNome.getText();
                String marca = txtMarca.getText();

                double valor = Double.parseDouble(
                        txtValor.getText().replace(",", ".")
                );

                int quantidade = Integer.parseInt(
                        txtQuantidade.getText()
                );

                Produto produto = new Produto(
                        id,
                        nome,
                        marca,
                        valor,
                        quantidade
                );

                dao.atualizarProduto(produto);

                JOptionPane.showMessageDialog(
                        null,
                        "Produto atualizado com sucesso!"
                );

                limparCampos();
                listarProdutos();

            } catch (Exception erro) {

                JOptionPane.showMessageDialog(
                        null,
                        "Erro ao atualizar produto!"
                );
            }
        });

        // EXCLUIR
        btnExcluir.addActionListener(e -> {

            try {

                int id = Integer.parseInt(txtId.getText());

                dao.excluirProduto(id);

                JOptionPane.showMessageDialog(
                        null,
                        "Produto excluído com sucesso!"
                );

                limparCampos();
                listarProdutos();

            } catch (Exception erro) {

                JOptionPane.showMessageDialog(
                        null,
                        "Erro ao excluir produto!"
                );
            }
        });

        // LIMPAR
        btnLimpar.addActionListener(e -> {
            limparCampos();
        });

        listarProdutos();
    }

    // MÉTODO LISTAR
    private void listarProdutos() {

        modeloTabela.setRowCount(0);

        List<Produto> produtos = dao.listarProdutos();

        for (Produto p : produtos) {

            modeloTabela.addRow(new Object[]{
                    p.getId(),
                    p.getNome(),
                    p.getMarca(),
                    p.getPreco(),
                    p.getQuantidade()
            });
        }
    }

    // MÉTODO LIMPAR
    private void limparCampos() {

        txtId.setText("");
        txtNome.setText("");
        txtMarca.setText("");
        txtValor.setText("");
        txtQuantidade.setText("");
    }
}