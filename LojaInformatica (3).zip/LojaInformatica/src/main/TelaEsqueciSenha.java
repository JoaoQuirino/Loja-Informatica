package main;

import dao.UsuarioDAO;

import javax.swing.*;
import java.awt.*;

public class TelaEsqueciSenha extends JFrame {

    public TelaEsqueciSenha() {
        setTitle("Esqueci a Senha");
        setSize(400, 300);
        setLocationRelativeTo(null);
        setLayout(null);

        JLabel titulo = new JLabel("Recuperar Senha");
        titulo.setFont(new Font("Arial", Font.BOLD, 22));
        titulo.setBounds(100, 30, 250, 30);
        add(titulo);

        JLabel lblEmail = new JLabel("E-mail:");
        lblEmail.setBounds(50, 90, 100, 25);
        add(lblEmail);

        JTextField txtEmail = new JTextField();
        txtEmail.setBounds(140, 90, 180, 25);
        add(txtEmail);

        JLabel lblNovaSenha = new JLabel("Nova senha:");
        lblNovaSenha.setBounds(50, 130, 100, 25);
        add(lblNovaSenha);

        JPasswordField txtNovaSenha = new JPasswordField();
        txtNovaSenha.setBounds(140, 130, 180, 25);
        add(txtNovaSenha);

        JButton btnAlterar = new JButton("Alterar Senha");
        btnAlterar.setBounds(140, 190, 180, 35);
        add(btnAlterar);

        btnAlterar.addActionListener(e -> {
            String email = txtEmail.getText();
            String novaSenha = new String(txtNovaSenha.getPassword());

            UsuarioDAO dao = new UsuarioDAO();

            boolean alterou = dao.atualizarSenha(email, novaSenha);

            if (alterou) {
                JOptionPane.showMessageDialog(null, "Senha alterada com sucesso!");
                dispose();
            } else {
                JOptionPane.showMessageDialog(null, "E-mail não encontrado!");
            }
        });
    }
}