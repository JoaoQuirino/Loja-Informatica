package main;

import dao.UsuarioDAO;

import javax.swing.*;
import java.awt.*;

public class TelaLogin extends JFrame {

    public TelaLogin() {
        setTitle("Login");
        setSize(400, 320);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(null);

        JLabel titulo = new JLabel("Login do Sistema");
        titulo.setFont(new Font("Arial", Font.BOLD, 22));
        titulo.setBounds(100, 30, 250, 30);
        add(titulo);

        JLabel lblEmail = new JLabel("E-mail:");
        lblEmail.setBounds(50, 90, 100, 25);
        add(lblEmail);

        JTextField txtEmail = new JTextField();
        txtEmail.setBounds(140, 90, 180, 25);
        add(txtEmail);

        JLabel lblSenha = new JLabel("Senha:");
        lblSenha.setBounds(50, 130, 100, 25);
        add(lblSenha);
        JPasswordField txtSenha = new JPasswordField();
        txtSenha.setBounds(140, 130, 180, 25);
        add(txtSenha);

        JButton btnEntrar = new JButton("Entrar");
        btnEntrar.setBounds(140, 175, 180, 30);
        add(btnEntrar);

        JButton btnNovoUsuario = new JButton("Novo Usuário");
        btnNovoUsuario.setBounds(50, 225, 130, 30);
        add(btnNovoUsuario);

        JButton btnEsqueciSenha = new JButton("Esqueci a Senha");
        btnEsqueciSenha.setBounds(190, 225, 150, 30);
        add(btnEsqueciSenha);

        btnEntrar.addActionListener(e -> {
            String email = txtEmail.getText();
            String senha = new String(txtSenha.getPassword());

            UsuarioDAO dao = new UsuarioDAO();
            String nomeUsuario = dao.autenticar(email, senha);

            if (nomeUsuario != null) {
                JOptionPane.showMessageDialog(null, "Login realizado com sucesso!");

                TelaProdutos tela = new TelaProdutos(nomeUsuario);
                tela.setVisible(true);

                dispose();
            } else {
                JOptionPane.showMessageDialog(null, "E-mail ou senha incorretos!");
            }
        });

        btnNovoUsuario.addActionListener(e -> {
            TelaNovoUsuario tela = new TelaNovoUsuario();
            tela.setVisible(true);
        });

        btnEsqueciSenha.addActionListener(e -> {
            TelaEsqueciSenha tela = new TelaEsqueciSenha();
            tela.setVisible(true);
        });
    }
}