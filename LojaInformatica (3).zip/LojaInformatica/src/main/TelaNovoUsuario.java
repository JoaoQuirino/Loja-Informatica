package main;

import dao.UsuarioDAO;
import model.Usuario;

import javax.swing.*;
import java.awt.*;

public class TelaNovoUsuario extends JFrame {

    public TelaNovoUsuario() {
        setTitle("Novo Usuário");
        setSize(400, 350);
        setLocationRelativeTo(null);
        setLayout(null);

        JLabel titulo = new JLabel("Cadastrar Novo Usuário");
        titulo.setFont(new Font("Arial", Font.BOLD, 20));
        titulo.setBounds(70, 30, 300, 30);
        add(titulo);

        JLabel lblNome = new JLabel("Nome:");
        lblNome.setBounds(50, 90, 100, 25);
        add(lblNome);

        JTextField txtNome = new JTextField();
        txtNome.setBounds(140, 90, 180, 25);
        add(txtNome);

        JLabel lblEmail = new JLabel("E-mail:");
        lblEmail.setBounds(50, 130, 100, 25);
        add(lblEmail);

        JTextField txtEmail = new JTextField();
        txtEmail.setBounds(140, 130, 180, 25);
        add(txtEmail);

        JLabel lblSenha = new JLabel("Senha:");
        lblSenha.setBounds(50, 170, 100, 25);
        add(lblSenha);

        JPasswordField txtSenha = new JPasswordField();
        txtSenha.setBounds(140, 170, 180, 25);
        add(txtSenha);

        JButton btnCadastrar = new JButton("Cadastrar");
        btnCadastrar.setBounds(140, 230, 180, 35);
        add(btnCadastrar);

        btnCadastrar.addActionListener(e -> {
            try {
                String nome = txtNome.getText();
                String email = txtEmail.getText();
                String senha = new String(txtSenha.getPassword());

                Usuario usuario = new Usuario(nome, email, senha);

                UsuarioDAO dao = new UsuarioDAO();
                dao.cadastrarUsuario(usuario);

                JOptionPane.showMessageDialog(null, "Usuário cadastrado com sucesso!");
                dispose();

            } catch (Exception erro) {
                JOptionPane.showMessageDialog(null, "Erro ao cadastrar usuário!");
            }
        });
    }
}